package roteiro3.parte1;

import java.util.Scanner;

public class Programa12 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        double sb, grat, imp, sr;

        System.out.println("Informe o salario base: ");
        sb = entrada.nextDouble();
        grat = Programa11.calcGrat(sb);
        imp = Programa11.calcImp(sb);
        sr = sb + grat - imp;

        System.out.println("Salario a receber: " + sr);
 
    }
    public static double calcularPercentual(double sb, double percentual){
        return sb *  percentual / 100;

    } 
}
    
    








