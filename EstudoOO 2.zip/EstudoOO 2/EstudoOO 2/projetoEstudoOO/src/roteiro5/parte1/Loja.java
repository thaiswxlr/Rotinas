package roteiro5.parte1;

public class Loja {
    private String nomeFantasia;
    private String razaoSocial;
    private String cnpj;
    private double valorFat;
    private double área;
    private String nomeProprietario;
    
    
}
