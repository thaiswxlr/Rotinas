package roteiro3.parte2;

import java.util.Scanner;

public class Programa14 {
    public static void main(String[] args) {
    
        Scanner entrada = new Scanner(System.in);

        System.out.println("Informe o valor de x: ");
        double x = entrada.nextDouble();
        System.out.println("Informe a operacao (+, -, *, /)");
        String op = entrada.next();
        System.out.println("Informe o valor de y:");
        double y = entrada.nextDouble();

        double resultado = 0;
        boolean operacaoValida = true;


        switch(op){
            case"+": soma(x,y);
              break;
              case"-": subtracao(x,y);
              break;
              case"*": multiplicacao(x,y);
              break;
              case"/": divisao(x,y);
              break;
            default:
                System.out.println("Operacao invalida");
               
        
        }
    
        if (operacaoValida){
            System.out.println("Resultado: " + resultado);
        }
    }         
    private static double soma(double x, double y) {
       return x + y;  
    }
    private static double subtracao(double x, double y) {
       return x - y;
    }
    private static double multiplicacao(double x, double y) {
        return x * y;
    }
    private static double divisao(double x, double y) {
        return x / y;

}
}
