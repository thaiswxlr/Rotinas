package roteiro7.parte1;

public class Aluno {
    public int matricula;
    public String nome;
    public String curso;
    public int anoIngresso;
    public int qtdDeDiciplinas;
    public String situacao;


    public Aluno (int matricula, String nome, String curso, int anoIngresso, int qtdDeDiciplinas, String situacao){
                 this.matricula = matricula;
                 this.nome = nome;
                 this.curso = curso;
                 this.anoIngresso = anoIngresso;
                 this.qtdDeDiciplinas = qtdDeDiciplinas;
                 this.situacao = situacao;
    }

    public int getmatricula(){
        return matricula;
    }
    public void setmatrucula(int matricula){
        this.matricula = matricula;
    }

    public String getnome(){
        return nome;
    }
    public void setnome(String nome){
        this.nome = nome;
    }

    public String getcurso(){
        return curso;
    }
   public void setcurso(String curso){
       this.curso = curso;
   }

   public int getanoIngresso(){
    return anoIngresso;
   }
   public void setanoIngresso(int anoIngresso){
        this.anoIngresso = anoIngresso;
   }

   public int getqtdDeDiciplinas(){
    return qtdDeDiciplinas;
   }
   public void setqtdDeDiciplinas (int qtdDeDiciplinas){
        this.qtdDeDiciplinas = qtdDeDiciplinas;    
   }

   public String getsituacao(){
    return situacao;
   }
   public void setsituacao (String situacao){
       this.situacao = situacao;
   }
}