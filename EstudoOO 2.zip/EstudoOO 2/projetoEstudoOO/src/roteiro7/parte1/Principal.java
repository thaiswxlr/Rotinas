package roteiro7.parte1;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

     Aluno[] listaAlunos = new Aluno [3];
     
     Aluno aluno01 = new Aluno (111,"Jose","Sistemas de informação", 2019, 0, null);
     Aluno aluno02 = new Aluno (122,"Maria","Engenharia Civil", 2020, 0, null);
     Aluno aluno03 = new Aluno (133,"Carlos","Química", 2021, 0, null);
     

     listaAlunos[0] = aluno01;
     listaAlunos[1] = aluno02;
     listaAlunos[2] = aluno03;

     System.out.println("Listando os alunos");
     System.out.println("*********************************");
     for (int i = 0; i < 3; i++){
    
     System.out.println("Matricula: "+ listaAlunos[i].getMatricula());
     System.out.println("Nome: "+ listaAlunos[i].getNome());
     System.out.println("Curso: "+ listaAlunos[i].getCurso());
     System.out.println("Ano Ingresso: "+ listaAlunos[i].get.AnoIngresso());
     System.out.println("************************************");

     }

     

    }

}
