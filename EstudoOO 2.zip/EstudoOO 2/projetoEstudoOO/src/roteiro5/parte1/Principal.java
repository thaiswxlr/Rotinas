package roteiro5.parte1;

public class Principal {
    
    public static void main(String[] args) {

        Loja loja01 = new Loja("Lojão da Cidade", "Lojão Comércio LTDA", "11223344");
        Loja loja02 = new Loja("Mercadão do Povo", "", "10101010");
        
    }
}

