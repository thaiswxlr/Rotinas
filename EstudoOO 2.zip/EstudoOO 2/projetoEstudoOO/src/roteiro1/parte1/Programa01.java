package roteiro1.parte1;

public class Programa01{

    public static void main(String[] args) {
        System.out.println("Primeiro Programa");
    }

}