package roteiro6.parte1;

public class Ligacao {

    private String numOrigem;
    private String numDestino;
	private String localOrigem;	
	private String horaInicio;
	private String horaFim;
    private String localDestino;
    
    
        public Ligacao(String numOrigem, String numDestino, String localOrigem, String localDestino, String horaInicio){
            this.numOrigem = numOrigem;
            this.numDestino = numDestino;
            this.localOrigem = localOrigem;
            this.localDestino = localDestino;
            this.horaInicio = horaInicio;
            this.horaFim = " ";
}

    public String getnumOrigem() {
    return numOrigem;
}
    public void setNumOrigem(String numOrigem) {
    this.numOrigem = numOrigem;
}

    public String getnumDestino(){
        return numDestino;
    }
    public void setNumDestino (String numDestino){
        this.numDestino = numDestino;
    }

    public String getlocalOrigem (){
        return localOrigem;
    }
    public void setLocalOrigem (String localOrigem){
        this.localOrigem = localOrigem;
    }

    public String getlocalDestino (){
        return localOrigem;
    }
    public void setLocalDestino (String localDestino){
        this.localDestino = localDestino;
    }
    
    public String gethorainicio (){
        return horaInicio;
    }
    public void setHoraInicio (String horaInicio){
        this.horaInicio = horaInicio;
    }

    public String gethoraFim (){
        return horaFim;
    }
    public void setHoraFim(String horaFim){
        this.horaFim = horaFim;
    }
    

}
