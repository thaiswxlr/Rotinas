package parte3;

public class Tempo {
    int hora;
    private int minuto;
    private int segundo;
        private Tempo tempo;
    
            public Tempo (int hora, int minuto, int segundo) {
                this.hora = hora;
                this.minuto = minuto;
                this.segundo = segundo;   
            }
            
            public int gethora() {
                return hora;
            }
                public void sethora(int hora) {
                this.hora = hora;
            }
    
            public int getminuto (){
                return minuto;
            }
            public void setminuto (int minuto){
                this.minuto = minuto;
            }
    
            public int getsegundo (){
                return segundo;
            }
            public void setsegundo (int segundo){
                this.segundo = segundo;
            }
    
            public int diferencaEmMinutos(Tempo outroTempo){
                int minutosInicio = this.hora * 60 + this.minuto;
                int minutosFim = outroTempo.hora * 60 + outroTempo.minuto;
                return Math.abs(minutosFim - minutosInicio);
            }
    
            public int diferencaEmMinutos(Tempo tempo) {
                        this.tempo = tempo;
                        return tempo.hora;
         
        
        }
        
    }
