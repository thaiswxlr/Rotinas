package parte3;

public class Ligacao {

    private String numOrigem;
    private String numDestino;
	private String localOrigem;	
    private String localDestino;
	private Tempo horaInicio;
	private Tempo horaFim;
   
        public Ligacao(String numOrigem, String numDestino, String localOrigem, String localDestino, Tempo horaInicio){
            this.numOrigem = numOrigem;
            this.numDestino = numDestino;
            this.localOrigem = localOrigem;
            this.localDestino = localDestino;
            this.horaInicio = horaInicio;
            this.horaFim = null;
}
    public Ligacao(String numOrigem2, String numDestino2, String localOrigem2, String localDestino2, String string) {
    
        }

        public boolean temNaLigacao (String numero){
            if (numero == null){
                return false;
            } else {
                return numero.equals(numOrigem) == numero.equals(numDestino);
            }
        }
        public double calcularValor(){
            if ( horaInicio == null || horaFim == null){
                 return 0.0;
             }
             int duracaoEmMinutos = horaFim.diferencaEmMinutos(horaInicio);
 
             double valorLigacao = duracaoEmMinutos *1.0;
             return valorLigacao;
         }




    public String getnumOrigem() {
    return numOrigem;
}
    public void setNumOrigem(String numOrigem) {
    this.numOrigem = numOrigem;
}

    public String getnumDestino(){
        return numDestino;
    }
    public void setNumDestino (String numDestino){
        this.numDestino = numDestino;
    }

    public String getlocalOrigem (){
        return localOrigem;
    }
    public void setLocalOrigem (String localOrigem){
        this.localOrigem = localOrigem;
    }

    public String getlocalDestino (){
        return localOrigem;
    }
    public void setLocalDestino (String localDestino){
        this.localDestino = localDestino;
    }
    
    public Tempo gethorainicio (){
        return horaInicio;
    }
    public void setHoraInicio (Tempo horaInicio){
        this.horaInicio = horaInicio;
    }

    public Tempo gethoraFim (){
        return horaFim;
    }
    public void setHoraFim(Tempo horaFim){
        this.horaFim = horaFim;
    }
    

}
