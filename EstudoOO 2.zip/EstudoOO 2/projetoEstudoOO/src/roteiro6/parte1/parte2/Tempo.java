package parte2;

public class Tempo {
    private int hora;
    private int minuto;
    private int segundo;

        public Tempo (int hora, int minuto, int segundo) {
            this.hora = hora;
            this.minuto = minuto;
            this.segundo = segundo;   
        }
        
        public int gethora() {
            return hora;
        }
            public void sethora(int hora) {
            this.hora = hora;
        }

        public int getminuto (){
            return minuto;
        }
        public void setminuto (int minuto){
            this.minuto = minuto;
        }

        public int getsegundo (){
            return segundo;
        }
        public void setsegundo (int segundo){
            this.segundo = segundo;
        }

        

    }
