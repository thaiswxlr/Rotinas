package parte2;

public class Principal {

   public static void main(String[] args) {
    Ligacao lig01 = new Ligacao("121212", "565656", "A", "B", "10:15:02");
   }

}
