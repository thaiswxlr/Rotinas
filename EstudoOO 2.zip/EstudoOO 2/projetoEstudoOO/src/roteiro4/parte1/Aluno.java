package roteiro4.parte1;

public class Aluno {
    public int matricula;
    public String ano;
    public String curso;
    public int anoIngresso;
    public String nome;


}
