package roteiro4.parte2;

public class Aluno {
    public int matricula;
    public String curso;
    public int anoIngresso;
    public String nome;

    public Aluno (int pMatricula, String pNome, String pCurso, int PAnoIngresso){
                matricula = pMatricula;
                nome = pNome;
                curso = pCurso;
                anoIngresso = PAnoIngresso;

    }

}
