package roteiro4.parte2;



public class Principal {
    public static void main(String[] args) {
        
        Aluno aluno01 = new Aluno(150, "Jose", "Sistema de Informação", 2019);
        Aluno aluno02 = new Aluno(250, "Carol", "Ciencias da Computação", 2020);

        System.out.println("\nDados do Aluno 01:");
        System.out.println("Matricula : " + aluno01.matricula);
        System.out.println("Nome : " + aluno01.nome);
        System.out.println("Curso : " + aluno01.curso);
        System.out.println("Ano Ingresso : " + aluno01.anoIngresso);

        System.out.println("\nDados do Aluno 02:");
        System.out.println("Matricula : " + aluno02.matricula);
        System.out.println("Nome : " + aluno02.nome);
        System.out.println("Curso : " + aluno02.curso);
        System.out.println("Ano Ingresso : " + aluno02.anoIngresso);

    }
}
