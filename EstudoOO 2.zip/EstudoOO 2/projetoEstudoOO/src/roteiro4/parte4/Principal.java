package roteiro4.parte4;

public class Principal {
    public static void main(String[] args) {

        
        Aluno aluno01 = new Aluno(150, "Jose", "Sistema de Informação", 2019);
  
     
        System.out.println("Matricula : " + aluno01.getMatricula());
        System.out.println("Nome : " + aluno01.getNome());
        System.out.println("Curso : " + aluno01.getCurso());
        System.out.println("Ano Ingresso : " + aluno01.getAnoIngresso());
        System.out.println("Quantidade de Disciplinas: " + aluno01.getQtdeDisciplinas());
        System.out.println("Situação: " + aluno01.getSituacao());

        aluno01.setMatricula(160);

        System.out.println("Matricula : " + aluno01.getMatricula());
        System.out.println("Nome : " + aluno01.getNome());
        System.out.println("Curso : " + aluno01.getCurso());
        System.out.println("Ano Ingresso : " + aluno01.getAnoIngresso());
        System.out.println("Quantidade de Disciplinas: " + aluno01.getQtdeDisciplinas());
        System.out.println("Situação: " + aluno01.getSituacao());
    }
}
